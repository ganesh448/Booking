package com.anudip.TrainTicketReservationSystemProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainTicketReservationSystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
