package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;
import com.anudip.TrainTicketReservationSystemProject.Exception.AdminNotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Admin;

public interface AdminService {
	
	List<Admin> getAllRecords() throws AdminNotFoundException;
	
	Admin getAdmin(String id) throws AdminNotFoundException;
	
	Admin updateAdmin(Admin admin) throws AdminNotFoundException;
	

}
