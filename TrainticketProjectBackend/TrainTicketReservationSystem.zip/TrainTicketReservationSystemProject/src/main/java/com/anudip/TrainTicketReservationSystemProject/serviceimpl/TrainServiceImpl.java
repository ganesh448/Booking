package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainFoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainNotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Train;
import com.anudip.TrainTicketReservationSystemProject.repository.TrainRepository;
import com.anudip.TrainTicketReservationSystemProject.service.TrainService;

@Service
public class TrainServiceImpl implements TrainService {
    
    @Autowired
	private TrainRepository trainRepository;

	@Override
	public List<Train> getAllRecords()throws TrainNotFoundException {
	
		List<Train> trainlist=trainRepository.findAll();
		if(trainlist.isEmpty()) 
		{
			throw new TrainNotFoundException("NO records of  are there.Please Enter the Trains First");
		}
		else
			return trainlist;
	}

	@Override
	public Train saveTrain(Train train) throws TrainFoundException {
		
		Optional<Train> existtrain = trainRepository.findById(train.getId());
		if(existtrain.isPresent())
		{
			throw new TrainFoundException("This Train already exist! Please add Another train ");
		}
		else
			return trainRepository.save(train);	
	}

	@Override
	public Train getTrain(Long id) throws TrainNotFoundException{
		
		Optional<Train> checktrain = trainRepository.findById(id);
		if(checktrain.isPresent())
		{
			return trainRepository.findById(id).get();
		}
		else
		{
			throw new TrainNotFoundException("There is No Train with this id");
		}
	}

	@Override
	public Train updateTrain(Train train) throws TrainNotFoundException{

		Optional<Train> checktrain = trainRepository.findById(train.getId());
		if(checktrain.isPresent())
		{
			return trainRepository.save(train);
		}
		else
		{
			throw new TrainNotFoundException("There is No Train with this id");
		}
	}

	@Override
	public String deleteTrain(Long id) throws TrainNotFoundException{
	
		Optional<Train> checktrain = trainRepository.findById(id);
		if(checktrain.isPresent())
		{
			trainRepository.deleteById(id);
			return " Train Record deleted";
		}
		else
		{
			throw new TrainNotFoundException("There is No Train with this id");
		}
		
	}
}
