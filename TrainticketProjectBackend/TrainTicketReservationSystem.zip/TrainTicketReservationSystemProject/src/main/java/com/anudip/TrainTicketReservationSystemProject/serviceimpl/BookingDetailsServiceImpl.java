package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.TrainTicketReservationSystemProject.entity.BookingDetails;
import com.anudip.TrainTicketReservationSystemProject.repository.BookingDetailsRepository;
import com.anudip.TrainTicketReservationSystemProject.service.BookingDetailsService;

@Service
public class BookingDetailsServiceImpl implements BookingDetailsService {

	@Autowired
    private BookingDetailsRepository bookingDetailsRepository;

    @Override
    public List<BookingDetails> getAllBookingDetails() {
        return bookingDetailsRepository.findAll();
    }

    @Override
    public BookingDetails getBookingDetailsById(Long id) {
        return bookingDetailsRepository.findById(id).orElse(null);
    }

    @Override
    public BookingDetails saveBookingDetails(BookingDetails bookingDetails) {
        return bookingDetailsRepository.save(bookingDetails);
    }

    @Override
    public void deleteBookingDetails(Long id) {
        bookingDetailsRepository.deleteById(id);
    }

    @Override
    public List<BookingDetails> getBookingDetailsByUserId(Long userId) {
        return bookingDetailsRepository.findByUserId(userId);
    }

    @Override
    public void deleteBookingDetailsByUserId(Long userId) {
        List<BookingDetails> bookingDetailsList = bookingDetailsRepository.findByUserId(userId);
        bookingDetailsRepository.deleteAll(bookingDetailsList);
    }
}
