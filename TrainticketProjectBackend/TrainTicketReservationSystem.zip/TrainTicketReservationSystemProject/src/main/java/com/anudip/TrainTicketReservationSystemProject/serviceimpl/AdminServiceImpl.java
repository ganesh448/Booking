package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.anudip.TrainTicketReservationSystemProject.Exception.AdminNotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Admin;
import com.anudip.TrainTicketReservationSystemProject.repository.AdminRepository;
import com.anudip.TrainTicketReservationSystemProject.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public List<Admin> getAllRecords()throws AdminNotFoundException {
		
		List<Admin> adminlist=adminRepository.findAll();
		if(adminlist.isEmpty()) 
		{
			throw new AdminNotFoundException("NO records are there.Please create Admin First!");
		}
		else
			return adminlist;
	}


	@Override
	public Admin getAdmin(String id) throws AdminNotFoundException{
		
		Optional<Admin> checkadmin=adminRepository.findById(id);
		if(checkadmin.isPresent())
		{
			return adminRepository.findById(id).get();
		}
		else
		{
			throw new AdminNotFoundException("There is No Admin with this id");
		}
	}

	@Override
	public Admin updateAdmin(Admin admin) throws AdminNotFoundException{

		Optional<Admin> checkadmin=adminRepository.findById(admin.getLoginid());
		if(checkadmin.isPresent())
		{
			return adminRepository.save(admin);
		}
		else
		{
			throw new AdminNotFoundException("There is No Admin with this id");
		}
	}	

}
