package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainFoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainNotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Train;

public interface TrainService {

	Train saveTrain(Train train)  throws TrainFoundException;
	
	Train getTrain(Long id) throws TrainNotFoundException;
	
	Train updateTrain(Train train) throws TrainNotFoundException;
	
	String deleteTrain(Long id) throws TrainNotFoundException;

	List<Train> getAllRecords() throws TrainNotFoundException;

}
