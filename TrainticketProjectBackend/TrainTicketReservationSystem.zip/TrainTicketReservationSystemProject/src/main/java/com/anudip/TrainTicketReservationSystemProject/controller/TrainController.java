package com.anudip.TrainTicketReservationSystemProject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainFoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.TrainNotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Train;
import com.anudip.TrainTicketReservationSystemProject.serviceimpl.TrainServiceImpl;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
//@RequestMapping("/trains")
public class TrainController {

	@Autowired
    TrainServiceImpl trainserviceimpl;	

	@GetMapping ("/api/getAllTrains")
	public ResponseEntity<List<Train>>getAllTrain() throws TrainNotFoundException
	{
		List<Train> newtrain = trainserviceimpl.getAllRecords();
		return new ResponseEntity<>(newtrain,HttpStatus.OK);
	}
	
	@PostMapping  ("/api/createTrain")
	public ResponseEntity<Train> addTrain(@RequestBody Train train) throws TrainFoundException 
	{
		Train newtrain=trainserviceimpl.saveTrain(train);
		return new ResponseEntity<>(newtrain,HttpStatus.CREATED);
	}
		
	
	@GetMapping("/api/getTrainById")
	public ResponseEntity<Train> getTrainById(@RequestParam Long id) throws TrainNotFoundException{

		Train train = trainserviceimpl.getTrain(id);
		return new ResponseEntity<>(train,HttpStatus.OK);

	}
	
	@PutMapping("/api/updateTrain/{id}") 
	public ResponseEntity<Train> updateTrain(@PathVariable Long id,@RequestBody Train train) throws TrainNotFoundException{
		Train updatetrain = new Train();
		updatetrain.setId(id);
		updatetrain.setCapacity(train.getCapacity());
		Train updatetrainnew=trainserviceimpl.updateTrain(train);
		return new ResponseEntity<>(updatetrainnew,HttpStatus.OK);

	}
	
	@DeleteMapping("/api/deleteTrain/{id}")
	public String deleteTrain(@PathVariable Long id) throws TrainNotFoundException
	{
		return trainserviceimpl.deleteTrain(id);
	}
	
}