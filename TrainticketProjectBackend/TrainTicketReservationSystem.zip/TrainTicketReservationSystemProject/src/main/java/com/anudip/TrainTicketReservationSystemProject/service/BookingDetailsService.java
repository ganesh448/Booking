package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;

import com.anudip.TrainTicketReservationSystemProject.entity.BookingDetails;

public interface BookingDetailsService {
	
	List<BookingDetails> getAllBookingDetails();

    BookingDetails getBookingDetailsById(Long id);

    BookingDetails saveBookingDetails(BookingDetails bookingDetails);

    void deleteBookingDetails(Long id);

    List<BookingDetails> getBookingDetailsByUserId(Long userId);

	void deleteBookingDetailsByUserId(Long userId);

}
