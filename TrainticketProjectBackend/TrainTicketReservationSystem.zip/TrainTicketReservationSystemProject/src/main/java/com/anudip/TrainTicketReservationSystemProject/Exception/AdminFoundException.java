package com.anudip.TrainTicketReservationSystemProject.Exception;

public class AdminFoundException extends Exception{

	
	private static final long serialVersionUID = 1L;
	public AdminFoundException() {
		super("This Admin id is already present in database");
		
	}
	public AdminFoundException(String message) {
		super(message);
		
	}

}
