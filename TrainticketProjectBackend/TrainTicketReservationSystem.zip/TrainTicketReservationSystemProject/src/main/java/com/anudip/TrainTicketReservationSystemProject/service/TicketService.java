package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;

import com.anudip.TrainTicketReservationSystemProject.entity.Ticket;

public interface TicketService {
	
	List<Ticket> getAllTickets();

    Ticket getTicketById(Long id);
    
    Ticket saveTicket(Ticket ticket);

    void deleteTicket(Long id);

    List<Ticket> getTicketsByBookingDetailsId(Long bookingDetailsId);

    List<Ticket> getTicketsBySeatNumber(String seatNumber);

}
