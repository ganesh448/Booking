package com.anudip.TrainTicketReservationSystemProject.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler({AdminNotFoundException.class})
	public ResponseEntity<?> HandleAdminNotFoundException(AdminNotFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
		
	}
	
	@ExceptionHandler({AdminFoundException.class})
	public ResponseEntity<?> HandleAdminFoundException(AdminFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
	}
	
	@ExceptionHandler({TrainNotFoundException.class})
	public ResponseEntity<?> HandleTrainNotFoundException(TrainNotFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
		
	}
	
	@ExceptionHandler({TrainFoundException.class})
	public ResponseEntity<?> HandleTrainFoundException(TrainFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
	}
	
	@ExceptionHandler({UserNotFoundException.class})
	public ResponseEntity<?> HandleUserNotFoundException(UserNotFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
		
	}
	
	@ExceptionHandler({UserFoundException.class})
	public ResponseEntity<?> HandleUserFoundException(UserFoundException ex)
	{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
	}
	
	

}
