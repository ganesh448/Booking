package com.anudip.TrainTicketReservationSystemProject.Exception;

public class TrainNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public TrainNotFoundException() {
		super("This Train is not there in List");		
	}

	public TrainNotFoundException(String message) {
		super(message);
		
	}

}
