package com.anudip.TrainTicketReservationSystemProject.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ticket {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long bookingDetailsId;
    private String seatNumber;
    private Long cost;
    public Ticket()
    {
    	super();
    	
    }
	public Ticket(Long bookingDetailsId, String seatNumber) {
		super();
		this.bookingDetailsId = bookingDetailsId;
		this.seatNumber = seatNumber;
	}

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getBookingDetailsId() {
		return bookingDetailsId;
	}

	public void setBookingDetailsId(Long bookingDetailsId) {
		this.bookingDetailsId = bookingDetailsId;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Long getCost() {
		return cost;
	}

	public void setCost(Long cost) {
		this.cost = cost;
	}
    
	@Override
	public String toString() {
		return "Ticket [id=" + id + ", bookingDetailsId=" + bookingDetailsId + ", seatNumber=" + seatNumber + ", cost="
				+ cost + "]";
	}

}
