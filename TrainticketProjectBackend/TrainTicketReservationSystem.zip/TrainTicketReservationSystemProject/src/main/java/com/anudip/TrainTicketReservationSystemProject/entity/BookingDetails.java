package com.anudip.TrainTicketReservationSystemProject.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BookingDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long trainId;
    private int numberOfSeats;
    private String sourceStation;
    private String destinationStation;
    private Long cost;
    public BookingDetails()
    {
    	super();
    }
	public BookingDetails( Long userId, Long trainId, int numberOfSeats,String sourceStation,String destinationStation, Long cost) {
		super();
		this.userId = userId;
		this.trainId = trainId;
		this.numberOfSeats = numberOfSeats;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.cost = cost;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getTrainId() {
		return trainId;
	}
	public void setTrainId(Long trainId) {
		this.trainId = trainId;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	public String getSourceStation() {
		return sourceStation;
	}
	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}
	public String getDestinationStation() {
		return destinationStation;
	}
	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}
	public void setCost(Long cost) {
	}
    
	@Override
	public String toString() {
	    return "BookingDetails [id=" + id + ", userId=" + userId + ", trainId=" + trainId +
	           ", numberOfSeats=" + numberOfSeats + ", sourceStation=" + sourceStation +
	           ", destinationStation=" + destinationStation + ", cost=" + cost + "]";
	}

}