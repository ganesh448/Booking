package com.anudip.TrainTicketReservationSystemProject.Exception;

public class TrainFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TrainFoundException() {
		super("This Train is already present");
		
	}
	public TrainFoundException(String message) {
		super(message);
		
	}

}
