package com.anudip.TrainTicketReservationSystemProject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.entity.BookingDetails;
import com.anudip.TrainTicketReservationSystemProject.serviceimpl.BookingDetailsServiceImpl;


@RestController
@RequestMapping("/booking-details")
@CrossOrigin("http://localhost:4200")
public class BookingDetailsController {
	
    @Autowired
    private BookingDetailsServiceImpl bookingDetailsService;

    @GetMapping
    public ResponseEntity<List<BookingDetails>> getAllBookingDetails() {
        List<BookingDetails> bookingDetails = bookingDetailsService.getAllBookingDetails();
        return new ResponseEntity<>(bookingDetails, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingDetails> getBookingDetailsById(@PathVariable Long id) {
        BookingDetails bookingDetail = bookingDetailsService.getBookingDetailsById(id);
        return bookingDetail != null
                ? new ResponseEntity<>(bookingDetail, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping
    public ResponseEntity<BookingDetails> saveBookingDetails(@RequestBody BookingDetails bookingDetails) {
        BookingDetails savedBookingDetails = bookingDetailsService.saveBookingDetails(bookingDetails);
        return new ResponseEntity<>(savedBookingDetails, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBookingDetailsByUserId(@PathVariable Long id) {
        bookingDetailsService.deleteBookingDetailsByUserId(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Example custom endpoint
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingDetails>> getBookingDetailsByUserId(@PathVariable Long userId) {
        List<BookingDetails> bookingDetails = bookingDetailsService.getBookingDetailsByUserId(userId);
        return new ResponseEntity<>(bookingDetails, HttpStatus.OK);
    }
    @GetMapping("/success")
    public String showBookingSuccess() {
        return "booking-success";
    }
}
